let heading = document.querySelector("h2");


document.querySelector("button").addEventListener("click", function(){
//    heading.style.display = "block";
//    heading.setAttribute("class", "show");
    heading.setAttribute("style", "display:block");

})





