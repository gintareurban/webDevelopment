let form1 = document.querySelector("form");


document.querySelector("button").addEventListener("click", function(){
//    form1.style.display = "block";
    form1.setAttribute("class", "show");
//    form1.setAttribute("style", "display:block");

})

document.getElementById("pateikti").addEventListener("click", function(){
    alert("Dekojame uz Jusu nuomone.");
})





